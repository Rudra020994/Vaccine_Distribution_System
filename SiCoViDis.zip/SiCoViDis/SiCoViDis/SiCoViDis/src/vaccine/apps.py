from django.apps import AppConfig


class VaccineConfig(AppConfig):
    name = 'vaccine'
